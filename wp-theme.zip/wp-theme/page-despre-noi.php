<?php get_header(); ?>

<div id="content">
  <div id="page-header" style="background: url(<?php echo get_template_directory_uri().'/_content/despre-noi.jpg' ?>) no-repeat top center;">

    <div id="page-header-title"><?php echo get_the_title()?></div>

  </div><!-- end #page-header -->

  <div class="row" style="margin-bottom: 30px;">
    <div id="breadcrumbs">
      <a href="http://localhost/wordpress/index.php/acasa/"> Acasa </a> > <?php echo get_the_title()?>
    </div>
  </div><!-- end .row -->

  <div class="row">
    <div class="span12">

          <h2 class="headline"><span>Cine <span class="text-highlight-2">suntem ?</span></span></h2>

      </div><!-- end .span12 -->
  </div><!-- end .row -->

  <div class="row" style="padding-bottom: 50px;">
    <div class="span4">

        <p class="text-center"><img class="responsive-img" src="<?php echo get_template_directory_uri().'/_content/300x345.png' ?>" alt=""></p>

      </div><!-- end .span4 -->
      <div class="span8">

          <p style="text-align: justify">Suntem o societate cu capital integral privat, iar domeniul principal de activitate il constituie Constructiile Civile Industriale si Agricole. Am luat nastere in 2006, din dorinta de a lasa ceva in urma, ceva trainic. Drumul nostru a inceput cu o echipa de 20 oameni. </p>


          <p style="text-align: justify">Prima noastra activitate urma sa apara la scurt timp in orasul Sibiu. Constructia de mansarde pe blocuri a constituit debutul nostru in constructii. Am continuat cu constructii de case si blocuri, axandu-ne doar pe structura de rezistenta. Urmati de necesitatile clientilor am inceput sa executam si lucrari de finisaje. Din acelasi motiv o echipa care sa acopere si aria instalatiilor in constructii, s-a format. Dupa cum stiti la finele fiecarei lucrari de finisaje, praful si dezordinea pun stapanire pe cladire.</p>
          <p style="text-align: justify">Acest fapt a condus la ideea de a forma o alta echipa de aceasta data pentru curatenie, ca mai tarziu, sa fie completata de mesteri pentru a asigura mentenanta pe termen lung a acestor cladiri.</p>
          <p style="text-align: justify">Astazi putem spune ca avem suficienta experienta pentru a oferi servicii de consultanta, proiectare si executie in domeniul constructiilor. Pornind de la aceeasi idee am ales ca experienta noastra sa o impartasim cu dumneavoastra, cei care isi doresc sa colaboreze cu o echipa profesionista ca a noastra.</p>
          <p style="text-align: justify">Calitatea serviciilor si seriozitatea sunt elementele principale dupa care ne ghidam. Telul nostru este de a realiza proiecte la standarde ridicate si de a oferii servicii de cea mai buna calitate.</p>

      </div><!-- end .span8 -->
  </div><!-- end .row -->

</div>

<?php get_footer(); ?>
