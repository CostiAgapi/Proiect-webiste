
<div id="footer">

<!-- /// FOOTER     ///////////////////////////////////////////////////////////////////////////////////////////////////////// -->

  <div class="row">
          <div class="span12">


              <!-- social icons -->

              <div class="fixed" id="social">

                    <a href="#" class="facebook-icon social-icon">
                        <i class="fa fa-facebook"></i>
                    </a>
                    <a href="#" class="twitter-icon social-icon">
                        <i class="fa fa-twitter"></i>
                    </a>
                    <a href="#" class="googleplus-icon social-icon">
                        <i class="fa fa-google-plus"></i>
                    </a>
                    <a href="#" class="pinterest-icon social-icon">
                        <i class="fa fa-pinterest"></i>
                    </a>
                    <a href="#" class="instagram-icon social-icon">
                        <i class="fa fa-instagram"></i>
                    </a>

                </div>


            </div><!-- end .span12 -->
        </div><!-- end .row -->

        <div class="row">

          <div class="span4" id="footer-widget-area-1">

               <div class="widget widget_text">

                    <div class="textwidget">
                        <p>
                          <strong>Email</strong>: office@popconstruct.ro<br>
                          <strong>Tel.</strong>: 0764.809.791</p>
                    </div>

                </div>

            </div><!-- end .span4 -->
          <div class="span3" id="footer-widget-area-3">
                <div class="widget widget_text">

                    <p><a href="#"><img class="responsive-img" src="<?php echo get_template_directory_uri().'/_layout/images/logo_footer.png' ?>" alt=""></a></p>

                </div>

              </div><!-- end .span4 -->
            </div><!-- end .row -->
        </div><!-- end #footer -->

<!-- //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// -->

    </div>
  </div><!-- end #wrap -->
  <script src="<?php echo get_template_directory_uri().'/_layout/js/viewport/jquery.viewport.js' ?>"></script>
  <script src="<?php echo get_template_directory_uri().'/_layout/js/easing/jquery.easing.1.3.js' ?>"></script>
  <script src="<?php echo get_template_directory_uri().'/_layout/js/easing/jquery.easing.1.3.js' ?>"></script>
  <script src="<?php echo get_template_directory_uri().'/_layout/js/simpleplaceholder/jquery.simpleplaceholder.js' ?>"></script>
  <script src="<?php echo get_template_directory_uri().'/_layout/js/fitvids/jquery.fitvids.js' ?>"></script>
  <script src="<?php echo get_template_directory_uri().'/_layout/js/superfish/hoverIntent.js' ?>"></script>
  <script src="<?php echo get_template_directory_uri().'/_layout/js/superfish/superfish.js' ?>"></script>
  <script src="<?php echo get_template_directory_uri().'/_layout/js/bxslider/jquery.bxslider.min.js' ?>"></script>
  <script src="<?php echo get_template_directory_uri().'/_layout/js/magnificpopup/jquery.magnific-popup.min.js' ?>"></script>
  <script src="<?php echo get_template_directory_uri().'/_layout/js/isotope/isotope.pkgd.min.js' ?>"></script>


  <script src="<?php echo get_template_directory_uri().'/_layout/js/parallax/jquery.parallax.min.js' ?>"></script>

  <script src="<?php echo get_template_directory_uri().'/_layout/js/isotope/imagesloaded.pkgd.min.js' ?>"></script>

  <script src="<?php echo get_template_directory_uri().'/_layout/js/easypiechart/jquery.easypiechart.min.js' ?>"></script>

  <script src="<?php echo get_template_directory_uri().'/_layout/js/easytabs/jquery.easytabs.min.js' ?>"></script>

  <script src="<?php echo get_template_directory_uri().'/_layout/js/jqueryvalidate/jquery.validate.min.js' ?>"></script>

  <script src="<?php echo get_template_directory_uri().'/_layout/js/jqueryform/jquery.form.min.js' ?>"></script>

  <script src="http://maps.google.com/maps/api/js?sensor=false"></script>

  <script src="<?php echo get_template_directory_uri().'/_layout/js/gmap/jquery.gmap.min.js' ?>"></script>

  <script src="<?php echo get_template_directory_uri().'/_layout/js/plugins.js' ?>"></script>

  <script src="<?php echo get_template_directory_uri().'/_layout/js/scripts.js' ?>"></script>
</body>
</html>
