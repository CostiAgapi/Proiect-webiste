<div class="row" style="padding-bottom: 50px;">

  <div class="span4">

        <div class="icon-box-2">

            <div class="icon_big">
              <span><?php single_term_title(); ?></span></span>
            </div><!-- end .icon -->

        </div><!-- end .icon-box-2 -->

    </div><!-- end .span4 -->
    <div class="span8">

      <?php
      $terms = get_terms( array(
          'taxonomy' => 'port_categorii',
          'child_of' =>get_queried_object_id(),
          'hide_empty' => false,
          'orderby'=>'id',
          'order' => 'ASC'
      ) );

      $counter=0;
    foreach($terms as $term){
        $counter++;

        if($counter%2==1){
          echo '<div class="span4" style="margin-left: 0px;">';
          echo '<div class="toggle-n-item">';
          echo '<a class="toggle-n-item-toggle" href="'.get_term_link($term).'">';
          echo '<i class="ifc-home"></i>'.$term->name;
          echo '</a>';
          echo '</div>';
          echo '</div>';

        }else {
          echo '<div class="span4">';
          echo '<div class="toggle-n-item">';
          echo '<a class="toggle-n-item-toggle" href="'.get_term_link($term).'">';
          echo '<i class="ifc-home"></i>'.$term->name;
          echo '</a>';
          echo '</div>';
          echo '</div>';
        }
      }

      ?>

      </div>

    </div><!-- end .span8 -->
</div><!-- end .row -->
