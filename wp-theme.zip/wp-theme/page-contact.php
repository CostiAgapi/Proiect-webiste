<?php get_header(); ?>

<div id="content">
  <div id="page-header" style="background: url(<?php echo get_template_directory_uri().'/_content/contact.jpg' ?>) no-repeat top center;">

    <div id="page-header-title"><?php echo get_the_title()?></div>

  </div><!-- end #page-header -->

  <div id="full-contact-info">

    <div id="google-map" class="map" data-zoom="16" data-address="Bulevardul Constructorilor, Bucuresti, Romania" data-caption="Office location 1" >
          <p>This will be replaced with the Google Map.</p>
      </div>

<div id="contact-info-wrap">
          <div id="contact-info">

                  <div class="widget ewf_widget_contact_info">

                      <ul>
                          <li class="address">
                              Bulevardul Constructorilor,<br />
                              sector 6,<br>
                              Bucuresti
                          </li>
                          <li class="email">
                              <a href="office@futurearchitecture.com">office@futurearchitecture.com</a>
                          </li>
                          <li class="phone">
                              0757.435.247
                          </li>
                      </ul>

                  </div>

                  <div class="hr" style="border-color:#444;"></div>

                  <form class="fixed" id="contact-form"  name="contact-form" method="post" action="_layout/php/send.php">
                      <fieldset>
                          <div id="formstatus"></div>
                          <label class="validation-error">Campurile cu * sunt obligatorii</label>
                          <p>
                              <input type="text" id="nume" name="nume" value="" placeholder="nume" />
                          </p>
                          <p>
                              <input type="text" id="email" name="email" value="" placeholder="e-mail address" />
                          </p>
                          <p>
                              <input type="text" id="telefon" name="telefon" value="" placeholder="07"  />
                          </p>
                          <p>
                              <input type="text" id="subiect" name="subiect" value="" placeholder="subiect"  />
                          </p>
                          <p>
                              <textarea id="mesaj" name="mesaj" rows="3" cols="25" placeholder="mesajul tau"></textarea>
                          </p>
                          <p>
                              <input id="submit" type="submit" name="submit" class="btn" value="Trimite!" />
                          </p>
                      </fieldset>
                  </form><!-- end #contact-form -->

          </div><!-- end #contact-info -->
</div><!-- end .contact-info-wrap -->

  </div><!-- end #full-contact-info -->

</div>

<?php get_footer(); ?>
