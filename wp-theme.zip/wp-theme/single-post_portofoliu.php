<?php get_header(); ?>

<div id="content">

  <?php

 if ( have_posts() ) : while ( have_posts() ) : the_post();

      $taxo=get_the_terms( $post->ID, 'port_categorii' );

      $args = array(
          'post_type' => 'attachment',
          'numberposts' => -1,
          'post_status' => 'any',
          'post_parent' => $post->ID
      );

      $images_id=array();
      $images_url=array();

      $attachments = get_posts( $args );
          if ( $attachments ) {
          foreach ( $attachments as $attachment ) {
          $images_id[]=$attachment->ID;
          $images_url[]=wp_get_attachment_image_url( $attachment->ID, 'full' );
          }

          asort($images_id);
      }

    endwhile; endif;

      $poza_cea_mare="";
      $images_size=array(array());
      foreach($images_id as $id){
          $images_size[$id]=wp_get_attachment_image_src($id,'full');
      }
    //scoate imaginea de banner din array
      foreach($images_size as $id => $propr){
        if($propr[1]>460){
          //storeaza poza mare
          $poza_cea_mare=$images_size[$id];
          unset($images_size[$id]);
        }
      }

  ?>
  <!--

    ATENTIE ! A SE MODIFICA URL DE LA BACKGROUND DACA ACESTA SE DORESTE A FI DINAMIC

     -->
  <div id="page-header" style="background: url(<?php echo get_template_directory_uri().'/_content/1920x485.png' ?>) no-repeat top center;">

    <div id="page-header-title">Portofoliu</div>

  </div><!-- end #page-header -->

  <div class="row" style="margin-bottom: 30px;">
    <div id="breadcrumbs">
    <a href="http://localhost/wordpress/index.php/acasa/"> Acasa </a> > <a href="http://localhost/wordpress/index.php/portofoliu/"> Portofoliu</a> > <a href="<?php echo get_term_link($taxo[0]); ?>"> <?php echo $taxo[0]->name; ?></a> > <?php echo get_the_title()?>
    </div>
  </div><!-- end .row -->

  <div class="row">
    <div class="span12">

          <h2 class="headline"><span>Lucrariile <span class="text-highlight-2">noastre</span></span></h2>

      </div><!-- end .span12 -->
  </div><!-- end .row -->

  <div class="row" style="padding-bottom: 50px;">
    <div class="span6 magnificPopup-gallery">
        <!-- imagini -->
          <?php

            $first_element=reset($images_size);
            $last_element=end($images_size);

            reset($images_size);
            $key = key($images_size);
            unset($images_size[$key]);
            $trebuie_pus_row=false; // se pune row nou dupa poza mare

            $counter=0;

            foreach($images_size as $id => $propr){
              if($propr[1]>220){
                $trebuie_pus_row=true;
                echo "<p>";
                echo '<a class="portfolio-item-zoom" href="'.wp_get_attachment_image_url( $id, 'full' ).'">';
                echo "<img src=".wp_get_attachment_image_url( $id, 'full' ).">";
                echo "</a>";
                echo "</p>";
                $counter++;
              }else{
                if($trebuie_pus_row){
                    echo '<div class="row">';
                }

                if($counter%2==1){
                  echo '<div class="span3" style="margin-left: 0px">';
                }else{
                  echo '<div class="span3">';
                }
                echo "<p>";
                echo '<a class="portfolio-item-zoom" href="'.wp_get_attachment_image_url( $id, 'full' ).'">';
                echo "<img src=".wp_get_attachment_image_url( $id, 'full' ).">";
                echo "</a>";
                echo "<p>";
                echo "</div>";
                $trebuie_pus_row=false;
                $counter++;

                if($propr==$last_element){
                    echo "</div>";
                }
              }
            }

           ?>

    </div><!-- end .span6 -->
      <div class="span6">
        <!-- paragrafe -->
          <?php
            $content_full=apply_filters('the_content',get_the_content());

            $nr_de_liste=substr_count ($content_full,"<ul");

            $content_inainte_de_ul=substr($content_full, 0, strpos($content_full,"<ul"));

            echo $content_inainte_de_ul;

            $content_ul = str_replace($content_inainte_de_ul, "", $content_full);


            echo '<div class="row">';

            $ul_uri = explode("<ul",$content_ul);
            end($ul_uri);
            $ultima_cheie = key($ul_uri);
            $sfag=$ul_uri[$ultima_cheie];
            $de_sters=substr($sfag,strpos($sfag,'<p')); // este contentul dupa ul-uri
            $ul_uri[$ultima_cheie]= str_replace($de_sters, "", $ul_uri[$ultima_cheie]);

            reset($ul_uri);
            $cheie = key($ul_uri);
            unset($ul_uri[0]);
            $contor=0;

            foreach ($ul_uri as $ul){
              $contor++;
              if($contor%2==0){

                echo '<div class="span3" style="margin-left= 0px;">';
                echo '<ul'.$ul;
                echo '</div>';
              }else{
                echo '<div class="span3">';
                echo '<ul'.$ul;
                echo '</div>';
              }

            }
              echo "</div>"; //close row
              echo "<br>";
              echo $de_sters;


          ?>
              <br>

      </div><!-- end .span6 -->
  </div><!-- end .row -->

</div>
<!-- javascript sa adauge clasa de selectata pentru pagina servicii -->
<script type="text/javascript">
  $( ".menu-item").eq(2).addClass("current-menu-item");
</script>

<?php get_footer(); ?>
