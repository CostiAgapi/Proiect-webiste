<?php

function includeCssFiles(){
	wp_enqueue_style( 'base', get_template_directory_uri().'/_layout/css/base.css' );
	wp_enqueue_style( 'elements', get_template_directory_uri().'/_layout/css/elements.css' );
	wp_enqueue_style( 'grid', get_template_directory_uri().'/_layout/css/grid.css' );
	wp_enqueue_style( 'layout', get_template_directory_uri().'/_layout/css/layout.css' );
	wp_enqueue_style( 'base', get_template_directory_uri().'/_layout/css/base.css' );
	wp_enqueue_style( 'animate.min', get_template_directory_uri().'/_layout/css/animate/animate.min.css' );
	wp_enqueue_style( 'font-awesome.min', get_template_directory_uri().'/_layout/css/fontawesome/font-awesome.min.css' );
	wp_enqueue_style( 'magnific-popup', get_template_directory_uri().'/_layout/js/magnificpopup/magnific-popup.css' );
	wp_enqueue_style( 'jquery.bxslider', get_template_directory_uri().'/_layout/js/bxslider/jquery.bxslider.css' );
	wp_enqueue_style( 'icon-font-custom', get_template_directory_uri().'/_layout/css/iconfontcustom/icon-font-custom.css' );
	wp_enqueue_script( 'modernizr', get_template_directory_uri().'/_layout/js/modernizr-2.6.2.min.js' );
	wp_enqueue_script( 'jquery-2.1.0.min', get_template_directory_uri().'/_layout/js/jquery-2.1.0.min.js' );
}

add_action( 'wp_enqueue_scripts', 'includeCssFiles' );
add_action( 'after_setup_theme', 'custom_setup' );

/*  Redirect*/

function redirect_homepage() {
		if(is_home()){
    wp_redirect( 'http://localhost/wordpress/index.php/acasa/',301 );
    exit;
	}
}

add_action( 'template_redirect', 'redirect_homepage' );

// afisare post fara imagine
add_filter('the_content', 'strip_images');
function strip_images($content){
	 return preg_replace('/<img[^>]+./','',$content);
}



if ( ! function_exists( 'custom_setup' ) ):

function custom_setup() {
	error_reporting(0);

	register_nav_menus( array(
		'top-menu-bar' => __( 'Top menu area' ) ,
		'header-menu-bar' => __( 'Main menu area' ) ,
		'footer-menu-bar' => __( 'Footer menu area' ) ,
	)  );

}

if ( function_exists('register_sidebar') ){
    register_sidebar( array(
		'name' => __( 'Home Widget Area', 'twentyten' ),
		'id' => 'home-widget-area',
		'description' => __( 'Homepage widget area', 'twentyten' ),
		'before_widget' => '<div class="widget_item %2$s">',
		'after_widget' => '</div>',
		'before_title' => '<h2 class="widget-title">',
		'after_title' => '</h2>',
	) );
	 register_sidebar( array(
		'name' => __( 'Main Widget Area', 'twentyten' ),
		'id' => 'main-widget-area',
		'description' => __( 'Inner page widget area', 'twentyten' ),
		'before_widget' => '<div class="widget_item %2$s">',
		'after_widget' => '</div>',
		'before_title' => '<h2 class="widget-title">',
		'after_title' => '</h2>',
	) );
}

function string_limit_words($string, $word_limit)
{
  $words = explode(' ', $string, ($word_limit + 1));
  if(count($words) > $word_limit)
  array_pop($words);
  return implode(' ', $words);
}

add_theme_support('post-thumbnails');

add_filter('show_admin_bar', '__return_false');

register_post_type( 'serviciu',
    array(
        'labels'                => array(
            'name'              => __( 'Serviciu' ),
            'singular_name'     => __( 'Serviciu' )
            ),
        'public'                => true,
        'show_ui'               => true,
        'show_in_menu'          => true,
        'supports'              => array( 'title', 'editor', "thumbnail", "author", "custom-fields", "comments"),
        'rewrite'               => array( 'slug' => 'serviciu', 'with_front' => true ),
        'has_archive'           => true,
		'menu_position'			=> 6
    )
);

		register_post_type( 'post_portofoliu',
		    array(
		        'labels'                => array(
		            'name'              => __( 'Portofoliu' ),
		            'singular_name'     => __( 'Portofoliu' )
		            ),
		        'public'                => true,
		        'show_ui'               => true,
		        'show_in_menu'          => true,
		        'supports'              => array( 'title', 'editor', "thumbnail", "author", "custom-fields", "comments"),
		        'rewrite'               => array( 'slug' => 'post_portofoliu', 'with_front' => true ),
		        'has_archive'           => true,
						'menu_position'			=> 7
		    )
		);


$labels_1 = array(
		'name'                          => 'Categorii',
		'singular_name'                 => 'Categorie',
		'search_items'                  => 'Cauta Categorie',
		'popular_items'                 => 'Popular Categorii',
		'all_items'                     => 'Toate Categoriile',
		'parent_item'                   => 'Parinte Categorie',
		'edit_item'                     => 'Editeaza Categorie',
		'update_item'                   => 'Update Categorie',
		'add_new_item'                  => 'Adauga Categorie',
		'new_item_name'                 => 'Categorie noua',
		'separate_items_with_commas'    => 'Separa categorie cu virgula',
		'add_or_remove_items'           => 'Adauga sau sterge categorie',
		'choose_from_most_used'         => 'Alege din cele mai utilizate categorii'
);


$args_1 = array(
		'label'                         => 'Categorii',
		'labels'                        => $labels_1,
		'public'                        => true,
		'hierarchical'                  => true,
		'show_ui'                       => true,
		'show_in_nav_menus'             => true,
		'args'                          => array( 'orderby' => 'term_order' ),
		'rewrite'                       => array( 'slug' => 'categorii', 'with_front' => false ),
		'query_var'                     => true
);

register_taxonomy( 'categorii_servicii', 'serviciu', $args_1 );

$labels_2 = array(
		'name'                          => 'Categorii portofoliu',
		'singular_name'                 => 'Categorie portofoliu',
		'search_items'                  => 'Cauta Categorie',
		'popular_items'                 => 'Popular Categorii',
		'all_items'                     => 'Toate Categoriile',
		'parent_item'                   => 'Parinte Categorie',
		'edit_item'                     => 'Editeaza Categorie',
		'update_item'                   => 'Update Categorie',
		'add_new_item'                  => 'Adauga Categorie',
		'new_item_name'                 => 'Categorie noua',
		'separate_items_with_commas'    => 'Separa categorie cu virgula',
		'add_or_remove_items'           => 'Adauga sau sterge categorie',
		'choose_from_most_used'         => 'Alege din cele mai utilizate categorii'
);

		$args_2 = array(
				'label'                         => 'Categorii portofoliu',
				'labels'                        => $labels_2,
				'public'                        => true,
				'hierarchical'                  => true,
				'show_ui'                       => true,
				'show_in_nav_menus'             => true,
				'args'                          => array( 'orderby' => 'term_order' ),
				'rewrite'                       => array( 'slug' => 'port_categ', 'with_front' => false ),
				'query_var'                     => true
		);

		register_taxonomy( 'port_categorii', 'post_portofoliu', $args_2 );



endif;

//Rewrite template hierarchy


?>
