<?php get_header(); ?>

<?php

$poza="";
// poza banner pt fiecare categorie de taxonomie
  if(single_term_title( "", false )=="Constructii"){
    $poza ="constructii1.jpg";
  }else if(single_term_title( "", false )=="Proiectare"){
    $poza ="proiectare.jpg";
  }else if(single_term_title( "", false )=="Consultanta"){
    $poza ="consultanta-in-constructii.jpg";
  }else{
    $poza ="mentenanta1.jpg";
  }

 ?>


<div id="content">
  <div id="page-header" style="background: url(<?php echo get_template_directory_uri().'/_content/'.$poza; ?>) no-repeat top center;">

    <div id="page-header-title">Servicii</div>

  </div><!-- end #page-header -->

  <div class="row" style="margin-bottom: 30px;">
    <div id="breadcrumbs">
      <a href="http://localhost/wordpress/index.php/acasa/"> Acasa </a> > <a href="http://localhost/wordpress/index.php/servicii/"> Servicii</a> > <?php single_term_title(); ?>
    </div>
  </div><!-- end .row -->

  <div class="row">
    <div class="span12">

          <h2 class="headline"><span>Serviciile <span class="text-highlight-2">noastre</span></span></h2>

      </div><!-- end .span12 -->
  </div><!-- end .row -->

  <div class="row" style="padding-bottom: 50px;">

    <div class="span4">

          <div class="icon-box-2">

              <div class="icon_big">
                <span><?php single_term_title(); ?></span></span>
              </div><!-- end .icon -->

          </div><!-- end .icon-box-2 -->

      </div><!-- end .span3 --><!-- end .span4 -->
      <div class="span8">

        <?php
        $counter=0;
          if ( have_posts() ) : while ( have_posts() ) : the_post();
          $counter++;

          if($counter%2==1){
            echo '<div class="span4" style="margin-left: 0px;">';
            echo '<div class="toggle-n-item">';
            echo '<a class="toggle-n-item-toggle" href="'.get_permalink().'">';
            echo '<i class="ifc-home"></i>'.get_the_title();
            echo '</a>';
            echo '</div>';
            echo '</div>';

          }else {
            echo '<div class="span4">';
            echo '<div class="toggle-n-item">';
            echo '<a class="toggle-n-item-toggle" href="'.get_permalink().'">';
            echo '<i class="ifc-home"></i>'.get_the_title();
            echo '</a>';
            echo '</div>';
            echo '</div>';
          }

          endwhile; else :
            _e( 'Sorry, no posts matched your criteria.' );
          endif;
        ?>

        </div>

      </div><!-- end .span8 -->
  </div><!-- end .row -->

</div>
<script type="text/javascript">
  $( ".menu-item").eq(2).addClass("current-menu-item");
</script>
<?php get_footer(); ?>
