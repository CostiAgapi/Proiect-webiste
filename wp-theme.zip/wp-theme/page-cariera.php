<?php get_header(); ?>

<div id="content">
  <div id="page-header" style="background: url(<?php echo get_template_directory_uri().'/_content/cariere.jpg' ?>) no-repeat top center;">

    <div id="page-header-title"><?php echo get_the_title()?></div>

  </div><!-- end #page-header -->

  <div class="row" style="margin-bottom: 30px;">
    <div id="breadcrumbs">
      <a href="http://localhost/wordpress/index.php/acasa/"> Acasa </a> > <?php echo get_the_title()?>
    </div>
  </div><!-- end .row -->

  <div class="row">
    <div class="span3">
      <a href="">Tehician in constructii</a>
    </div>
    <div class="span9">

          <h2 class="headline" style="margin-bottom: 20px;"><span>Job-uri <span class="text-highlight-2">disponibile</span></span></h2>
          <p>Se spune ca istoria constructiilor a inceput in urma cu 7000 ani in Mesopotamia, o regiune care in prezent apartine unor teritorii din Irak, Siria si Turcia. Ca si acum, casele celor bogati erau mari cu doua sau trei niveluri si in general podul locuibil. Curtile erau spatioase in jurul caselor. O alta categorie de constructii erau palatele regesti foarte mari si impunatoare frumos decorate cu ziduri ce aveau basoreliefuri sculptate in fildes in care se gaseau descrierile victoriilor din batalii.</p>
          <p>Constructiile din zilele noastre sunt mult mai complexe si cu mai multe functionalitati. Daca la inceputuri omul a fost culegator dupa aceea a devenit vanator ca mai apoi agricultor si constructor, astazi aceste meserii sau indeletniciri s-au dezvoltat foarte mult iar domeniul constructiilor a suferit schimbari majore cu privire la materiale si utilajele folosite pentru construit si specializarile aferente realizalii unei constructii.</p>
          <p>Chiar de la infiintare popconstruct.ro a folosit tehnologii de ultima generatie in ceea ce priveste executia lucrarilor in constructii si odata cu aceasta ne-am dezvoltat si noi. Suntem pregatiti sa facem fata oricaror cerinte si exigente in acest domeniu. Avem o echipa tanara si un cadru colectiv dinamic orientat spre performanta si calitate. Daca esti o persoana muncitoare, responsabila, serioasa si poti aduce un plus dezvoltarii companiei, echipa noastra isi doreste sa ne fii alaturi in proiectele viitoare pe care impreuna sa le ducem la bun sfarsit.</P>

      </div><!-- end .span12 -->
  </div><!-- end .row -->


<br><br><br>
</div>

<?php get_footer(); ?>
