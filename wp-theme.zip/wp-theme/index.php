<?php get_header(); ?>
<div id="content">

<!-- /// CONTENT  /////////////////////////////////////////////////////////////////////////////////////////////////////////// -->
            <div id="main-slider">
              <ul class="slides">
                  <li style="background: url(<?php echo get_template_directory_uri().'/_content/constructii-bucuresti1.jpg' ?>) ;">

                        <div class="slidetext">

                            <h1>Executam lucrari de constructii si finisaje.</h1>
                            <br>
                            <br>
                            <br>
                            <a class="btn btn-large btn-white text-uppercase" href="#"><strong>Mai Mult</strong></a>

                        </div><!-- end .slidetext -->

                    </li>
                    <li style="background: url(<?php echo get_template_directory_uri().'/_content/proiectare-constructii.jpg' ?>) ;">

                        <div class="slidetext">

                            <h1 style='color:#000 !important;'>Oferim servicii profesionale de proiectare in constructii.</h1>
                            <br>
                            <br>
                            <br>
                            <a class="btn btn-large btn-black text-uppercase" href="#"><strong>Mai Mult</strong></a>

                        </div><!-- end .slidetext -->

                    </li>
                    <li style="background: url(<?php echo get_template_directory_uri().'/_content/consultanta-in-constructii2.jpg' ?>);">

                        <div class="slidetext">

                            <h1 style='color:#000 !important;'>Oferim servicii de consultanta pentru constructii.</h1>
                            <br>
                            <br>
                            <br>
                            <a class="btn btn-large btn-black text-uppercase" href="#"><strong>Mai Mult</strong></a>

                        </div>

                    </li>
                    <li style="background: url(<?php echo get_template_directory_uri().'/_content/mentenanta-in-constructii.jpg' ?>);">

                        <div class="slidetext">

                            <h1>Oferim servicii de mentenanta pentru orice tip de constructie.</h1>
                            <br>
                            <br>
                            <br>
                            <a class="btn btn-large btn-white text-uppercase" href="#"><strong>Mai Mult</strong></a>

                        </div><!-- end .slidetext -->

                    </li>
                </ul><!-- end .slides -->
            </div><!-- end #main-slider -->

            <div class="row">

              <?php
              $terms = get_terms( array(
                  'taxonomy' => 'categorii_servicii',
                  'hide_empty' => false,
                  'orderby'=>'id',
                  'order' => 'ASC'
              ) );
              ?>

            	<div class="span3">

                    <div class="icon-box-2">

                        <div class="icon">
                        	<i class="fa fa-compass"></i>
                        </div><!-- end .icon -->

                        <div class="icon-box-content">
                        	<h4>
                            	<strong>
                                	<a href="<?php echo get_term_link($terms[0]); ?>"><?php echo $terms[0]->name; ?></a>
                                </strong>
                            </h4>
                        </div><!-- end .icon-box-content -->

                    </div><!-- end .icon-box-2 -->

                </div><!-- end .span3 -->
                <div class="span3">

                    <div class="icon-box-2">

                        <div class="icon">
                        	<img src="_layout/images/icons/2.png" alt="">
                        </div><!-- end .icon -->

                        <div class="icon-box-content">
                        	<h4>
                            	<strong>
                                	<a href="<?php echo get_term_link($terms[1]); ?>"><?php echo $terms[1]->name; ?></a>
                                </strong>
                            </h4>
                        </div><!-- end .icon-box-content -->

                    </div><!-- end .icon-box-2 -->

                </div><!-- end .span3 -->
                <div class="span3">

                    <div class="icon-box-2">

                        <div class="icon">
                        	<i class="ifc-log_cabine"></i>
                        </div><!-- end .icon -->

                        <div class="icon-box-content">
                        	<h4>
                            	<strong>
                                	<a href="<?php echo get_term_link($terms[2]); ?>"><?php echo $terms[2]->name; ?></a>
                                </strong>
                            </h4>
                        </div><!-- end .icon-box-content -->

                    </div><!-- end .icon-box-2 -->

                </div><!-- end .span3 -->
                <div class="span3">

                    <div class="icon-box-2">

                        <div class="icon">
                        	<img src="_layout/images/icons/4.png" alt="">
                        </div><!-- end .icon -->

                        <div class="icon-box-content">
                        	<h4>
                            	<strong>
                                	<a href="<?php echo get_term_link($terms[3]); ?>"><?php echo $terms[3]->name; ?></a>
                                </strong>
                            </h4>
                        </div><!-- end .icon-box-content -->

                    </div><!-- end .icon-box-2 -->

                </div><!-- end .span3 -->
            </div><!-- end .row -->
<!-- ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// -->

</div><!-- end #content -->

<?php get_footer(); ?>
