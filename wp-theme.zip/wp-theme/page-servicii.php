<?php get_header(); ?>

<div id="content">
  <div id="page-header" style="background: url(<?php echo get_template_directory_uri().'/_content/servicii.jpg' ?>) no-repeat top center;">

    <div id="page-header-title"><?php echo get_the_title()?></div>

  </div><!-- end #page-header -->

  <div class="row" style="margin-bottom: 30px;">
    <div id="breadcrumbs">
      <a href="http://localhost/wordpress/index.php/acasa/"> Acasa </a> > <?php echo get_the_title()?>
    </div>
  </div><!-- end .row -->

  <div class="row">
    <div class="span12">

          <h2 class="headline"><span>Serviciile <span class="text-highlight-2">noastre</span></span></h2>

      </div><!-- end .span12 -->
  </div><!-- end .row -->

  <div class="row">
    <div class="span3">

          <div class="icon-box-2">

              <div class="icon">
                <img src="_layout/images/icons/1.png" alt="">
              </div><!-- end .icon -->

              <?php
              $terms = get_terms( array(
                  'taxonomy' => 'categorii_servicii',
                  'hide_empty' => false,
                  'orderby'=>'id',
                  'order' => 'ASC'
              ) );
              ?>

              <div class="icon-box-content">
                <h4>
                    <strong>
                        <a href="<?php echo get_term_link($terms[0]); ?>"><?php echo $terms[0]->name; ?></a>
                      </strong>
                  </h4>

                  <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam sit amet malesuada magna.
                  vitae, volutpat et augue.</p>

              </div><!-- end .icon-box-content -->

          </div><!-- end .icon-box-2 -->

      </div><!-- end .span3 -->
      <div class="span3">

          <div class="icon-box-2">

              <div class="icon">
                <img src="_layout/images/icons/2.png" alt="">
              </div><!-- end .icon -->

              <div class="icon-box-content">
                <h4>
                    <strong>
                        <a href="<?php echo get_term_link($terms[1]); ?>"><?php echo $terms[1]->name; ?></a>
                      </strong>
                  </h4>

                  <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam sit amet malesuada magna.
                  vitae, volutpat et augue.</p>

              </div><!-- end .icon-box-content -->

          </div><!-- end .icon-box-2 -->

      </div><!-- end .span3 -->
      <div class="span3">

          <div class="icon-box-2">

              <div class="icon">
                <i class="ifc-log_cabine"></i>
              </div><!-- end .icon -->

              <div class="icon-box-content">
                <h4>
                    <strong>
                        <a href="<?php echo get_term_link($terms[2]); ?>"><?php echo $terms[2]->name; ?></a>
                      </strong>
                  </h4>

                  <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam sit amet malesuada magna.
                  vitae, volutpat et augue.</p>

              </div><!-- end .icon-box-content -->

          </div><!-- end .icon-box-2 -->

      </div><!-- end .span3 -->
      <div class="span3">

          <div class="icon-box-2">

              <div class="icon">
                <img src="_layout/images/icons/4.png" alt="">
              </div><!-- end .icon -->

              <div class="icon-box-content">
                <h4>
                    <strong>
                        <a href="<?php echo get_term_link($terms[3]); ?>"><?php echo $terms[3]->name; ?></a>
                      </strong>
                  </h4>
                  <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam sit amet malesuada magna.
                  vitae, volutpat et augue.</p>
              </div><!-- end .icon-box-content -->

          </div><!-- end .icon-box-2 -->

      </div><!-- end .span3 -->
  </div><!-- end .row -->

  <div class="parallax" style="background-image:url(<?php echo get_template_directory_uri().'/_content/1920350.png' ?>); padding:20px 0;">

      <div class="row">
        <div class="span2">

              <div class="milestone fixed">

                  <div class="milestone-content">
                      <span class="milestone-value" data-stop="38" data-speed="2000"></span>
                      <div class="milestone-description">Projects</div>
                  </div>

            </div><!-- end .milestone -->

          </div><!-- end .span2 -->
          <div class="span2">

              <div class="milestone fixed">

                  <div class="milestone-content">
                      <span class="milestone-value" data-stop="21" data-speed="2000"></span>
                      <div class="milestone-description">Proposals</div>
                  </div>

            </div><!-- end .milestone -->

          </div><!-- end .span2 -->
          <div class="span2">

              <div class="milestone fixed">

                  <div class="milestone-content">
                      <span class="milestone-value" data-stop="40" data-speed="2000"></span>
                      <div class="milestone-description">Clients</div>
                  </div>

            </div><!-- end .milestone -->

          </div><!-- end .span2 -->
          <div class="span2">

              <div class="milestone fixed">

                  <div class="milestone-content">
                      <span class="milestone-value" data-stop="5" data-speed="2000"></span>
                      <div class="milestone-description">Countries</div>
                  </div>

            </div><!-- end .milestone -->

          </div><!-- end .span2 -->
          <div class="span2">

              <div class="milestone fixed">

                  <div class="milestone-content">
                      <span class="milestone-value" data-stop="3" data-speed="1000"></span>
                      <div class="milestone-description">Parteners</div>
                  </div>

            </div><!-- end .milestone -->

          </div><!-- end .span2 -->
          <div class="span2">

              <div class="milestone fixed">

                  <div class="milestone-content">
                      <span class="milestone-value" data-stop="2" data-speed="1000"></span>
                      <div class="milestone-description">Award</div>
                  </div>

            </div><!-- end .milestone -->

          </div><!-- end .span2 -->
      </div><!-- end .row -->

  </div><!-- end .parallax -->
<br><br><br>
</div>

<?php get_footer(); ?>
