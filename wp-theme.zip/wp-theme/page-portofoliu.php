<?php get_header(); ?>

<div id="content">
  <div id="page-header" style="background: url(<?php echo get_template_directory_uri().'/_content/portofoliu_main_categ.jpg' ?>) no-repeat top center;">

    <div id="page-header-title"><?php echo get_the_title()?></div>

  </div><!-- end #page-header -->

  <div class="row" style="margin-bottom: 30px;">
    <div id="breadcrumbs">
      <a href="http://localhost/wordpress/index.php/acasa/"> Acasa </a> > <?php echo get_the_title()?>
    </div>
  </div><!-- end .row -->

  <div class="row">
    <div class="span12">

          <h2 class="headline"><span>Lucrarile <span class="text-highlight-2">noastre</span></span></h2>

      </div><!-- end .span12 -->
  </div><!-- end .row -->

  <div class="row">
    <div class="span3">

          <div class="icon-box-2">

              <div class="icon">
                <img src="_layout/images/icons/1.png" alt="">
              </div><!-- end .icon -->

              <?php
              $terms = get_terms( array(
                  'taxonomy' => 'port_categorii',
                  'hide_empty' => false,
                  'orderby'=>'id',
                  'order' => 'ASC'
              ) );
              ?>

              <div class="icon-box-content">
                <h4>
                    <strong>
                        <a href="<?php echo get_term_link($terms[0]); ?>"><?php echo $terms[0]->name; ?></a>
                      </strong>
                  </h4>

              </div><!-- end .icon-box-content -->

          </div><!-- end .icon-box-2 -->

      </div><!-- end .span3 -->
      <div class="span3">

          <div class="icon-box-2">

              <div class="icon">
                <img src="_layout/images/icons/2.png" alt="">
              </div><!-- end .icon -->

              <div class="icon-box-content">
                <h4>
                    <strong>
                        <a href="<?php echo get_term_link($terms[1]); ?>"><?php echo $terms[1]->name; ?></a>
                      </strong>
                  </h4>

              </div><!-- end .icon-box-content -->

          </div><!-- end .icon-box-2 -->

      </div><!-- end .span3 -->
      <div class="span3">

          <div class="icon-box-2">

              <div class="icon">
                <i class="ifc-log_cabine"></i>
              </div><!-- end .icon -->

              <div class="icon-box-content">
                <h4>
                    <strong>
                        <a href="<?php echo get_term_link($terms[2]); ?>"><?php echo $terms[2]->name; ?></a>
                      </strong>
                  </h4>

              </div><!-- end .icon-box-content -->

          </div><!-- end .icon-box-2 -->

      </div><!-- end .span3 -->
      <div class="span3">

          <div class="icon-box-2">

              <div class="icon">
                <img src="_layout/images/icons/4.png" alt="">
              </div><!-- end .icon -->

              <div class="icon-box-content">
                <h4>
                    <strong>
                        <a href="<?php echo get_term_link($terms[3]); ?>"><?php echo $terms[3]->name; ?></a>
                      </strong>
                  </h4>

              </div><!-- end .icon-box-content -->

          </div><!-- end .icon-box-2 -->

      </div><!-- end .span3 -->
  </div><!-- end .row -->
<br><br><br>
</div>

<?php get_footer(); ?>
