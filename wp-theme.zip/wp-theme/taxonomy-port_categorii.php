<?php get_header(); ?>

<?php

$poza="";
// poza banner pt fiecare categorie de taxonomie
  // if(single_term_title( "", false )=="Constructii"){
  //   $poza ="constructii1.jpg";
  // }else if(single_term_title( "", false )=="Proiectare"){
  //   $poza ="proiectare.jpg";
  // }else if(single_term_title( "", false )=="Consultanta"){
  //   $poza ="consultanta-in-constructii.jpg";
  // }else{
  //   $poza ="mentenanta1.jpg";
  // }

 ?>


<div id="content">
  <div id="page-header" style="background: url(<?php echo get_template_directory_uri().'/_content/'.$poza; ?>) no-repeat top center;">

    <div id="page-header-title">Portofoliu</div>

  </div><!-- end #page-header -->

  <div class="row" style="margin-bottom: 30px;">
    <div id="breadcrumbs">
      <a href="http://localhost/wordpress/index.php/acasa/"> Acasa </a> > <a href="http://localhost/wordpress/index.php/portofoliu/"> Portofoliu</a> > <?php single_term_title(); ?>
    </div>
  </div><!-- end .row -->

  <div class="row">
    <div class="span12">

          <h2 class="headline"><span>Lucrarile <span class="text-highlight-2">noastre</span></span></h2>

      </div><!-- end .span12 -->
  </div><!-- end .row -->

    <?php
    $obiectul=get_queried_object();
    $copii_term = get_terms( array(
        'taxonomy' => 'port_categorii',
        'childless' =>true,
        'hide_empty' => false,
        'orderby'=>'id',
        'order' => 'ASC'
    ) );

    if(in_array($obiectul,$copii_term)){
      include 'subcategorie.php';
    } else{
      include 'categorie.php';
    }
    ?>


</div>
<script type="text/javascript">
  $( ".menu-item").eq(3).addClass("current-menu-item");
</script>
<?php get_footer(); ?>
