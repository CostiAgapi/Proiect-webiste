<div class="row">
  <div class="span12   magnificPopup-gallery">
    <ul class="portfolio-items fixed">

  <?php

  $counter=0;

    if ( have_posts() ) : while ( have_posts() ) : the_post();
    $counter++;
    $args = array(
        'post_type' => 'attachment',
        'numberposts' => -1,
        'post_status' => 'any',
        'post_parent' => $post->ID
    );

    $images_id=array();
    $images_url=array();

    $attachments = get_posts( $args );
        if ( $attachments ) {
        foreach ( $attachments as $attachment ) {
        $images_id[]=$attachment->ID;
        $images_url[]=wp_get_attachment_image_url( $attachment->ID, 'full' );
        }

        asort($images_id);
    }

    $poza_cea_mare="";
    $images_size=array(array());
    foreach($images_id as $id){
        $images_size[$id]=wp_get_attachment_image_src($id,'full');
    }
  //scoate imaginea de banner din array
    foreach($images_size as $id => $propr){
      if($propr[1]==440){
        //storeaza poza mare
        $poza_cea_mare=$images_size[$id];

      }
    }

      echo '<li class="item term-'.$counter.'">';
      echo '<div class="portfolio-item">';
      echo '<div class="portfolio-item-preview">';
      echo '<a href="'.$poza_cea_mare[0].'">';
      echo '<img src="'.$poza_cea_mare[0].'" alt="">';
      echo '</a>';
      echo '<div class="portfolio-item-overlay">';
      echo '<div class="portfolio-item-description">';
      echo '<h4>';
      echo the_title();
      echo '<span></span></h4>';
      echo '<p>'.get_post_meta( get_the_ID(), 'Descriere' )[0].'</p>';
      echo '</div>';
      echo '<div class="portfolio-item-overlay-actions">';
      echo '<a class="portfolio-item-zoom" href="'.$poza_cea_mare[0].'">';
      echo '<i class="fa fa-search-plus"></i>';
      echo '</a>';
      echo '<a class="portfolio-item-link" href="portfolio-item.html">';
      echo '<i class="fa fa-angle-right"></i>';
      echo '</a>';
      echo '</div>';
      echo '</div>';
      echo '</div>';
      echo '</div>';
      echo '</li>';

    endwhile; else :
      _e( 'Sorry, no posts matched your criteria.' );
    endif;
  ?>

          </ul><!-- end .ul -->
        </div><!-- end .span12 -->

</div><!-- end .row -->
